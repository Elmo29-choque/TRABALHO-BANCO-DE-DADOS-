-- =====================================================================
-- 05_extras.sql : recursos de valorização (opcional, Capítulo 8)
-- Rode DEPOIS dos scripts 01 a 04.
-- =====================================================================
USE biblioteca;

-- 1) ALTER TABLE (faça DESCRIBE leitor; antes e depois)
ALTER TABLE leitor ADD COLUMN observacao VARCHAR(100);
ALTER TABLE leitor MODIFY COLUMN observacao VARCHAR(200);
ALTER TABLE leitor DROP COLUMN observacao;

-- 2) Transação: registrar empréstimo e marcar o exemplar como emprestado
START TRANSACTION;
INSERT INTO emprestimo (id_leitor, id_exemplar, data_emprestimo, data_devolucao_prevista)
VALUES (1, 24, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 14 DAY));
UPDATE exemplar SET status = 'emprestado' WHERE id_exemplar = 24;
ROLLBACK;   -- desfaz tudo (troque por COMMIT; para confirmar)

-- 3) Usuários e permissões (menor privilégio: só a view)
CREATE USER IF NOT EXISTS 'atendente'@'localhost' IDENTIFIED BY 'Senha#Forte123';
GRANT SELECT ON biblioteca.vw_emprestimo_detalhe TO 'atendente'@'localhost';
-- REVOKE SELECT ON biblioteca.vw_emprestimo_detalhe FROM 'atendente'@'localhost';

-- 4) Trigger: bloqueia empréstimo de exemplar que não está disponível (regra de negócio)
--    No Workbench/terminal o DELIMITER funciona; no phpMyAdmin, troque o campo "Delimitador".
DELIMITER $$
CREATE TRIGGER trg_emprestimo_valida
BEFORE INSERT ON emprestimo
FOR EACH ROW
BEGIN
  IF (SELECT status FROM exemplar WHERE id_exemplar = NEW.id_exemplar) <> 'disponivel' THEN
    SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'Exemplar indisponivel para emprestimo';
  END IF;
END$$
DELIMITER ;
-- Teste (deve falhar, exemplar 4 está emprestado):
-- INSERT INTO emprestimo (id_leitor, id_exemplar, data_emprestimo, data_devolucao_prevista)
-- VALUES (1, 4, CURDATE(), DATE_ADD(CURDATE(), INTERVAL 14 DAY));

-- 5) Backup (rode no TERMINAL, não no editor SQL):
--    mysqldump -u root -p biblioteca > backup_biblioteca.sql
--    mysql -u root -p biblioteca < backup_biblioteca.sql
